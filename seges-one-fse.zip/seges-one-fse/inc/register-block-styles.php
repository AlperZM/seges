<?php
/**
 * Block styles.
 *
 * @package seges-one-fse
 * @since 1.0.0
 */

/**
 * Register block styles
 *
 * @since 1.0.0
 *
 * @return void
 */
function seges_one_fse_register_block_styles() {

	register_block_style( // phpcs:ignore WPThemeReview.PluginTerritory.ForbiddenFunctions.editor_blocks_register_block_style
		'core/button',
		array(
			'name'  => 'seges-one-fse-flat-button',
			'label' => __( 'Flat button', 'seges-one-fse' ),
		)
	);

	register_block_style( // phpcs:ignore WPThemeReview.PluginTerritory.ForbiddenFunctions.editor_blocks_register_block_style
		'core/navigation',
		array(
			'name'  => 'seges-one-fse-navigation-button',
			'label' => __( 'Button style', 'seges-one-fse' ),
		)
	);

	register_block_style( // phpcs:ignore WPThemeReview.PluginTerritory.ForbiddenFunctions.editor_blocks_register_block_style
		'core/list',
		array(
			'name'  => 'seges-one-fse-list-underline',
			'label' => __( 'Underlined list items', 'seges-one-fse' ),
		)
	);

	register_block_style( // phpcs:ignore WPThemeReview.PluginTerritory.ForbiddenFunctions.editor_blocks_register_block_style
		'core/group',
		array(
			'name'  => 'seges-one-fse-box-shadow',
			'label' => __( 'Box shadow', 'seges-one-fse' ),
		)
	);

	register_block_style( // phpcs:ignore WPThemeReview.PluginTerritory.ForbiddenFunctions.editor_blocks_register_block_style
		'core/column',
		array(
			'name'  => 'seges-one-fse-box-shadow',
			'label' => __( 'Box shadow', 'seges-one-fse' ),
		)
	);

	register_block_style( // phpcs:ignore WPThemeReview.PluginTerritory.ForbiddenFunctions.editor_blocks_register_block_style
		'core/columns',
		array(
			'name'  => 'seges-one-fse-box-shadow',
			'label' => __( 'Box shadow', 'seges-one-fse' ),
		)
	);
}
add_action( 'init', 'seges_one_fse_register_block_styles' );

/**
 * This is an example of how to unregister a core block style.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-styles/
 * @see https://github.com/WordPress/gutenberg/pull/37580
 *
 * @since 1.0.0
 *
 * @return void
 */
function seges_one_fse_unregister_block_style() {
	wp_enqueue_script(
		'seges-one-fse-unregister',
		get_stylesheet_directory_uri() . '/assets/js/unregister.js',
		array( 'wp-blocks', 'wp-dom-ready', 'wp-edit-post' ),
		SEGES_ONE_FSE_VERSION,
		true
	);
}
add_action( 'enqueue_block_editor_assets', 'seges_one_fse_unregister_block_style' );
