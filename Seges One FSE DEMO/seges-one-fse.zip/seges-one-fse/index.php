<?php
/**
 * This file has been left empty on purpose.
 *
 * @link https://core.trac.wordpress.org/ticket/54272
 *
 * @package seges-one-fse
 * @since 1.0.0
 */
